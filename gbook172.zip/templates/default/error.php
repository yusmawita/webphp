<p>&nbsp;</p>
<p>&nbsp;</p>

<div style="text-align:center;font-size:larger;">
<span class="gbook_sign_error"><?php echo $lang['e19']; ?></span><br class="clear" />
<?php echo $myproblem; /* The actual error message */ ?>
</div>

<p>&nbsp;</p>
<p>&nbsp;</p>

<?php echo $backlink; /* Link to the previous page */ ?>

<p>&nbsp;</p>
